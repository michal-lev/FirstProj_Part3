package michal_liora;

public class NotExistException extends CollegeException{
    public NotExistException(String message){
        super(message);
    }
}