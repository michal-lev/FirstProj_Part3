package michal_liora;

public class CollegeException extends Exception{
    public CollegeException(String message){
        super(message);
    }
}
