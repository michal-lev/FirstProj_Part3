package michal_liora;

public class InvalidUserInputException extends CollegeException{
    public InvalidUserInputException(String message){
        super(message);
    }
}