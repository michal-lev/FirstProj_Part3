package michal_liora;

public class NoDuplicatesException extends CollegeException{
    public NoDuplicatesException(String message){
        super(message);
    }
}