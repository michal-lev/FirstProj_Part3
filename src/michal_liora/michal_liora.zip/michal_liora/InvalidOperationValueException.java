package michal_liora;

public class InvalidOperationValueException extends CollegeException{
    public InvalidOperationValueException(String message){
        super(message);
    }
}
